package com.ibm.customer.messae.consumer;

public interface CustomerMessageConsumer {
	public void consumeMessage(String addedBookMsg);
}
